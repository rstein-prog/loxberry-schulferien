#!/bin/bash
set -e

PLUGIN_FOLDER="$3"
LB_HOME="$5"

chmod +x "${LB_HOME}/bin/plugins/${PLUGIN_FOLDER}/schulferien_daemon.pl" 2>/dev/null || true
chmod +x "${LB_HOME}/bin/plugins/${PLUGIN_FOLDER}/restart_daemon.sh" 2>/dev/null || true
chmod +x "${LB_HOME}/webfrontend/htmlauth/plugins/${PLUGIN_FOLDER}/index.cgi" 2>/dev/null || true

mkdir -p "${LB_HOME}/log/plugins/${PLUGIN_FOLDER}" "${LB_HOME}/data/plugins/${PLUGIN_FOLDER}" || true
touch "${LB_HOME}/log/plugins/${PLUGIN_FOLDER}/schulferien.log" \
      "${LB_HOME}/data/plugins/${PLUGIN_FOLDER}/schulferien.log" 2>/dev/null || true
chown -R loxberry:loxberry "${LB_HOME}/log/plugins/${PLUGIN_FOLDER}" \
                            "${LB_HOME}/data/plugins/${PLUGIN_FOLDER}" 2>/dev/null || true

chmod +x "${LB_HOME}/system/cron/cron.reboot/${PLUGIN_FOLDER}" 2>/dev/null || true
chmod +x "${LB_HOME}/system/cron/cron.5min/${PLUGIN_FOLDER}" 2>/dev/null || true

RESTART="${LB_HOME}/bin/plugins/${PLUGIN_FOLDER}/restart_daemon.sh"
if [ -x "${RESTART}" ]; then
  bash "${RESTART}" "${LB_HOME}" "${PLUGIN_FOLDER}" 2>/dev/null || true
fi

echo "$(date -Iseconds 2>/dev/null || date) postinstall done" \
  >> "${LB_HOME}/data/plugins/${PLUGIN_FOLDER}/schulferien.log" 2>/dev/null || true

exit 0
