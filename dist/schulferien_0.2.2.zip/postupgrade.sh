#!/bin/bash

PTEMPDIR="$1"
PLUGIN_FOLDER="$3"
LB_HOME="${5:-${LBHOMEDIR:-/opt/loxberry}}"
RESTORE="${LB_HOME}/bin/plugins/${PLUGIN_FOLDER}/restore_user_data.sh"

if [ -x "${RESTORE}" ]; then
  bash "${RESTORE}" "${PTEMPDIR}" "${PLUGIN_FOLDER}" "${LB_HOME}" || true
fi

rm -rf "/tmp/${PTEMPDIR}_schulferien_userdata" 2>/dev/null || true

exit 0
