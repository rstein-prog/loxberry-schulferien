#!/usr/bin/env perl
use strict;
use warnings;
use CGI qw(:standard);
use CGI::Carp qw(fatalsToBrowser);
use File::Basename qw(dirname);
use File::Spec;
use JSON::PP qw(encode_json decode_json);

# ── Resolve paths ─────────────────────────────────────────────────────────────

my $SCRIPT_DIR    = dirname(File::Spec->rel2abs(__FILE__));
my $LB_HOME       = $ENV{LBHOMEDIR} // $ENV{LB_HOME}
    or die "LBHOMEDIR environment variable is not set";
my $PLUGIN_FOLDER = 'schulferien';

if ($SCRIPT_DIR =~ m{/htmlauth/plugins/([^/]+)$}) {
    $PLUGIN_FOLDER = $1;
} elsif ($ENV{LBPPLUGINDIR}) {
    $PLUGIN_FOLDER = $ENV{LBPPLUGINDIR};
}

my $BIN_DIR  = File::Spec->catfile($LB_HOME, 'bin',    'plugins', $PLUGIN_FOLDER);
my $DATA_DIR = File::Spec->catfile($LB_HOME, 'data',   'plugins', $PLUGIN_FOLDER);
my $LOG_FILE = File::Spec->catfile($LB_HOME, 'log',    'plugins', $PLUGIN_FOLDER, 'schulferien.log');
my $SCRIPT_URL = $ENV{SCRIPT_NAME} // "index.cgi";

unshift @INC, $BIN_DIR, File::Spec->catfile($LB_HOME, 'libs', 'perllib');

require Schulferien::Config;
require Schulferien::API;
require Schulferien::WebUI;

mkdir $DATA_DIR unless -d $DATA_DIR;

my $q    = CGI->new;
my $tab    = $q->param('tab')    || 'config';
my $action = $q->param('action') || '';

my $cfg = Schulferien::Config::load($LB_HOME, $PLUGIN_FOLDER);

# ── Plugin URL for icons ──────────────────────────────────────────────────────

my $plugin_url = '';
{
    my $uri = $SCRIPT_URL;
    $uri =~ s|/index\.cgi$||;
    $plugin_url = $uri;
}

# ── Actions ───────────────────────────────────────────────────────────────────

my ($message, $msg_type) = ('', 'info');

if ($action eq 'save_config') {
    # AJAX endpoint — must return JSON under all circumstances (no HTML from CGI::Carp)
    my ($json_ok, $json_err, $json_path) = (1, '', '');
    eval {
        my %new = (
            state                    => uc($q->param('state') // 'BY'),
            mqtt_base_topic          => $q->param('mqtt_base_topic') // 'loxberry/schulferien',
            mqtt_device_id           => lc($q->param('mqtt_device_id') // 'by'),
            mqtt_use_loxberry_broker => ($q->param('mqtt_use_loxberry_broker') ? 1 : 0),
            mqtt_host                => $q->param('mqtt_host')     // '',
            mqtt_port                => $q->param('mqtt_port')     // 1883,
            mqtt_user                => $q->param('mqtt_user')     // '',
            mqtt_password            => $q->param('mqtt_password') // '',
            poll_interval            => int($q->param('poll_interval') // 3600),
            enabled                  => ($q->param('enabled') ? 1 : 0),
        );
        $new{poll_interval} = 60 if $new{poll_interval} < 60;
        $json_path = Schulferien::Config::cfg_path($LB_HOME, $PLUGIN_FOLDER);
        my $save_err = Schulferien::Config::save($LB_HOME, $PLUGIN_FOLDER, \%new);
        if ($save_err) { $json_ok = 0; $json_err = $save_err; }
    };
    if ($@) { $json_ok = 0; $json_err = "Perl exception: $@"; }
    # Print header AFTER eval so CGI::Carp cannot inject HTML before it
    print "Content-Type: application/json; charset=utf-8\r\n\r\n";
    print encode_json({ ok => $json_ok ? 1 : 0, error => $json_err, debug_path => $json_path });
    exit;

} elsif ($action eq 'refresh_now') {
    my $state = uc($cfg->{state} // 'BY');
    my ($holidays, $err) = eval { Schulferien::API::fetch_holidays_multi_year(state => $state) };
    if ($@ || ($err && !@$holidays)) {
        $message  = 'API-Fehler: ' . ($@ || $err || 'unbekannt');
        $msg_type = 'error';
    } else {
        my $status  = Schulferien::API::compute_status($holidays);
        my $payload = Schulferien::API::build_mqtt_payload($status);

        # Save state for UI
        my $state_file = Schulferien::Config::state_store($DATA_DIR);
        if (open my $fh, '>', $state_file) {
            print $fh encode_json($status);
            close $fh;
        }

        # Publish via MQTT (best effort, non-fatal)
        eval {
            require Schulferien::LoxBerryMqtt;
            my ($mqtt, $info, $merr) = Schulferien::LoxBerryMqtt::connect_simple(
                use_loxberry_broker => $cfg->{mqtt_use_loxberry_broker} // 1,
                lb_home             => $LB_HOME,
                host                => $cfg->{mqtt_host}     // '',
                port                => $cfg->{mqtt_port}     // 1883,
                user                => $cfg->{mqtt_user}     // '',
                password            => $cfg->{mqtt_password} // '',
            );
            if ($mqtt) {
                my $base  = $cfg->{mqtt_base_topic}  // 'loxberry/schulferien';
                my $slug  = $cfg->{mqtt_device_id}   // lc($state);
                $mqtt->retain("$base/$slug/availability", 'online');
                $mqtt->retain("$base/$slug/data", encode_json($payload));
            }
        };

        my $is_hol = $status->{is_holiday} ? 'JA' : 'nein';
        my $next   = $status->{next_name} // '';
        my $ndays  = $status->{next_days}  // '';
        $message   = "Daten aktualisiert. Heute Ferientag: <strong>$is_hol</strong>."
                   . ($next ? " Nächste Ferien: <strong>$next</strong> in $ndays Tag(en)." : '');
        $msg_type  = 'success';
        $err ? ($message .= " (Teil-Fehler: $err)") : ();
    }
    $tab = 'monitor';

} elsif ($action eq 'restart_daemon') {
    my $restart_sh = File::Spec->catfile($BIN_DIR, 'restart_daemon.sh');
    if (-x $restart_sh) {
        system("bash $restart_sh $LB_HOME $PLUGIN_FOLDER >/dev/null 2>&1 &");
        $message  = 'Daemon-Neustart angestoßen. Seite in einigen Sekunden neu laden.';
        $msg_type = 'success';
    } else {
        $message  = 'restart_daemon.sh nicht gefunden.';
        $msg_type = 'error';
    }
    $tab = 'monitor';
}

# ── Output ────────────────────────────────────────────────────────────────────

print $q->header(-type => 'text/html', -charset => 'utf-8');

print Schulferien::WebUI::render_page(
    tab        => $tab,
    cfg        => $cfg,
    base_url   => $SCRIPT_URL,
    plugin_url => $plugin_url,
    message    => $message,
    msg_type   => $msg_type,
    data_dir   => $DATA_DIR,
    log_file   => $LOG_FILE,
);
